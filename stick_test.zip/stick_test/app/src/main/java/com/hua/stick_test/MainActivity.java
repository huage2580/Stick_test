package com.hua.stick_test;

import android.animation.ValueAnimator;
import android.support.annotation.NonNull;
import android.support.design.widget.CoordinatorLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    RecyclerView list;
    View stick;
    View icon;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        list = findViewById(R.id.list);
        list.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL,false));
        list.setAdapter(new TestAdapter());
        stick = findViewById(R.id.stick);
        icon = stick.findViewById(R.id.icon);
        CoordinatorLayout.LayoutParams lp= (CoordinatorLayout.LayoutParams) stick.getLayoutParams();
        Behaivor behaivor = (Behaivor) lp.getBehavior();
        behaivor.setCallBack(new Behaivor.ValueCallBack() {
            @Override
            public void onValueChange(float progress) {
                icon.setRotation(progress * 180);
            }

            @Override
            public void onRelease() {
                Toast.makeText(MainActivity.this,"跳转",Toast.LENGTH_SHORT).show();
            }
        });
    }

    class TestAdapter extends RecyclerView.Adapter<TestVH>{

        @NonNull
        @Override
        public TestVH onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item,viewGroup,false);
            return new TestVH(view);
        }

        @Override
        public void onBindViewHolder(@NonNull TestVH testVH, int i) {

        }

        @Override
        public int getItemCount() {
            return 10;
        }
    }

    class TestVH extends RecyclerView.ViewHolder{

        public TestVH(@NonNull View itemView) {
            super(itemView);
        }
    }

}
